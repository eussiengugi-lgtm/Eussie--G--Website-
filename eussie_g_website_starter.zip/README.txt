EUSSIE G WEBSITE STARTER

Files:
- index.html: responsive one-page website.

Already connected:
- YouTube: https://www.youtube.com/@eussiengugi
- TikTok: https://www.tiktok.com/@eussieg

Before publishing:
1. Replace the Facebook placeholder href in index.html with your exact Facebook Page URL.
2. Replace the Instagram placeholder href with your exact Instagram profile URL.
3. Review the wording and add your own photos/videos when ready.

This is a static website starter. It can be hosted free on GitHub Pages or Cloudflare Pages.
A custom .com domain normally requires purchasing domain registration separately.
